var express=require("express");
var mongoose= require("mongoose");
var $= require("jQuery");
var jsDom= require("jsdom");
var xml= require("xmlhttprequest");
var bodyParser=require("body-parser");


var app= express();

app.use(bodyParser());

mongoose.connect(process.env.MONGOLAB_URI || process.env.MONGOLAB_URL || "mongodb://localhost/2048-gamecenter");

var db= mongoose.connection;
db.on("error", console.error.bind(console, "Could not Connect to DB:")); 
db.once("open", function callback() {
	scoreProperties= mongoose.Schema ({
		username: String,
		score: Number,
		grid: String,
 		timeStamp: Date
		});

	score= mongoose.model("score", scoreProperties); 
});

app.get("/", function(req,res) {
	score.find({}).sort("-score").exec(function(err, scores){
		var scoreTable="<table><tr><th>username</th><th>score</th><th>date</th></tr>";
		if (scores.length!=0) {		
			for (var i=0; i<scores.length; i++) {
				table+="<tr>";
				table+="<td>"+ scores[i]["username"]+"</td>";
				table+="<td>"+ scores[i]["score"]+"</td>";
				table+="<td>"+ scores[i]["timeStamp"]+"</td>";			
				table+="</tr>";
				}
			table+="</table>";
			res.send(table);
		}
		else 	{
			res.send("<h2>No Scores Available</h2>");
		}
	});
});

app.post("/submit.json", function(req, res) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "X-Requested-With");
	var user=req.body.username;
	var playerScore=parseInt(request.body.score);
	var gameGrid=req.body.grid;
	var date=new Date();
	var tmpScore= new score({username:user, score: playerScore, grid:gameGrid, timeStamp:date});
	tmpScore.save(function(err, tmpScore) {
		if (err) {
			alert("Unable to save score to Database");
		}
	});
});

app.get("/scores.json", function(req, res) {
	res.set("Content-Type", "text/json");
	var player=req.query.username;
	score.find({username:player}).sort("-score").exec(function(scores) {
		res.send(scores);
	});
});


var port=Number(process.env.PORT || 5000);
app.listen(port, function() {
	console.log("Listening On" + port);
});
